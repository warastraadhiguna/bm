<?php
class MY_Model extends CI_Model
{
    protected $table = '';
    protected $order = '';

    public function __construct()
    {
        parent::__construct();

        // Set nama tabel secara otomatis jika tidak dideklarasikan
        // variabel $table di child class.
        if (!$this->table) {
            $this->table = strtolower(str_replace(
                'Model',
                '',
                get_class($this)
            ));
        }
    }

    //path , sheet#x#y

    function getDataFromExcelArray($path,$arrayCell)
    {
        require ( APPPATH . 'third_party/PHPExcel/Classes/PHPExcel.php');      
    
        $excelreader = new PHPExcel_Reader_Excel2007();
        $loadexcel = $excelreader->load($path);
        $resultArray = array();

        foreach ($arrayCell as $singleArray) 
        {
            $detailCells = explode("-",$singleArray[1]);
            $sheet =$loadexcel->setActiveSheetIndex($detailCells[0] - 1); 

            $result =  $sheet->getCellByColumnAndRow($this->getRowNumberFromAlpabeths($detailCells[1]),$detailCells[2])->getCalculatedValue();  

            if (isset($singleArray[2]))
            {
                if(!$singleArray[2])
                {
                    array_push($resultArray , array($singleArray[0],$result,''));
                }
                else
                {
                    $detailCells = explode("-",$singleArray[2]);
                    $sheet =$loadexcel->setActiveSheetIndex($detailCells[0] - 1); 

                   $resultRekomendasi =  $sheet->getCellByColumnAndRow($this->getRowNumberFromAlpabeths($detailCells[1]),$detailCells[2])->getCalculatedValue();

                    array_push($resultArray , array($singleArray[0],$result,$resultRekomendasi));
                }

            }
            else
            {
                array_push($resultArray , array($singleArray[0],$result));
            }
        }      

        return $resultArray;
    }

    function getDataFromExcel($path,$detailCell)
    {
        require ( APPPATH . 'third_party/PHPExcel/Classes/PHPExcel.php');    
        $excelreader = new PHPExcel_Reader_Excel2007();
        $loadexcel = $excelreader->load($path);

        $detailCells = explode("-",$detailCell);
        $sheet =$loadexcel->setActiveSheetIndex($detailCells[0] - 1); 

        return $sheet->getCellByColumnAndRow($this->getRowNumberFromAlpabeths($detailCells[1]),$detailCells[2])->getOldCalculatedValue();         
    }

    function getRowNumberFromAlpabeths($alphabeths)
    {
        $alphabeths = strtoupper($alphabeths);
        if(strlen($alphabeths) === 1)
        {
            return $this->getRowNumberFromAlpabeth($alphabeths);
        }
        else if(strlen($alphabeths) === 2)
        {
            return (26 * ($this->getRowNumberFromAlpabeth($alphabeths[0]) + 1)) + $this->getRowNumberFromAlpabeth($alphabeths[1]);
        }
        else if(strlen($alphabeths) === 3)
        {
            return (676 * ($this->getRowNumberFromAlpabeth($alphabeths[0])+1)) + (26 * ($this->getRowNumberFromAlpabeth($alphabeths[1]) + 1)) + $this->getRowNumberFromAlpabeth($alphabeths[1]);
        }  
    }

    function getRowNumberFromAlpabeth($alphabeth)
    {
        if(strtoupper($alphabeth) == 'A') return 0;
        else if(strtoupper($alphabeth) == 'B') return 1;
        else if(strtoupper($alphabeth) == 'C') return 2;
        else if(strtoupper($alphabeth) == 'D') return 3;
        else if(strtoupper($alphabeth) == 'E') return 4;
        else if(strtoupper($alphabeth) == 'F') return 5;
        else if(strtoupper($alphabeth) == 'G') return 6;
        else if(strtoupper($alphabeth) == 'H') return 7;
        else if(strtoupper($alphabeth) == 'I') return 8;
        else if(strtoupper($alphabeth) == 'J') return 9;
        else if(strtoupper($alphabeth) == 'K') return 10;
        else if(strtoupper($alphabeth) == 'L') return 11;
        else if(strtoupper($alphabeth) == 'M') return 12;
        else if(strtoupper($alphabeth) == 'N') return 13;
        else if(strtoupper($alphabeth) == 'O') return 14;
        else if(strtoupper($alphabeth) == 'P') return 15;
        else if(strtoupper($alphabeth) == 'Q') return 16;
        else if(strtoupper($alphabeth) == 'R') return 17;
        else if(strtoupper($alphabeth) == 'S') return 18;
        else if(strtoupper($alphabeth) == 'T') return 19;
        else if(strtoupper($alphabeth) == 'U') return 20;
        else if(strtoupper($alphabeth) == 'V') return 21;
        else if(strtoupper($alphabeth) == 'W') return 22;
        else if(strtoupper($alphabeth) == 'X') return 23;
        else if(strtoupper($alphabeth) == 'Y') return 24;
        else if(strtoupper($alphabeth) == 'Z') return 25;
    }

    function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    function update($id, $data)
    {
        $this->db->where('ID', $id);
        return $this->db->update($this->table, $data);
    }

    function update_by_table($table,$id, $data)
    {
        $this->db->where('ID', $id);
        return $this->db->update($table, $data);
    }    

    function update_where_table($table,$where, $data)
    {
        $this->db->where($where);
        return $this->db->update($table, $data);
    }    

    function getReverseDate($string)
    {
        $dates = explode("-", $string);
        return $dates[2] .'/'. $dates[1] . '/' . $dates[0];
    }

    function delete($id)
    {
        $this->db->where('ID', $id);
        $result = $this->db->delete($this->table);

        return $result;
    }

    function get_all($orderColumn)
    {
        $this->db->order_by($orderColumn, $this->order);
        return $this->db->get($this->table)->result();
    }   

    function get_all_table($table, $where = '')
    {
        if($where)
        {
            $this->db->where($where);
        }

        return $this->db->get($table)->result();
    }   

    function get_by_id($id)
    {
        $this->db->where('ID', $id);
        return $this->db->get($this->table)->row();
    }

    function get_by_id_table($id, $table)
    {
        $this->db->where('ID', $id);
        return $this->db->get($table)->row();
    }    

    function get_by_id_table_detail($id, $column , $table)
    {
        $this->db->where($column, $id);
        return $this->db->get($table)->row();
    }   

    function get_where_table($where, $table)
    {
        $this->db->where($where);
        return $this->db->get($table)->row();
    }         

    function getTanggalAwal()
    {
        $tanggalAwal = $this->input->get('tanggalAwal');
        return !$tanggalAwal ? date("d-m-Y") : $tanggalAwal;
    }    

    function getNamaUser()
    {
        $namaUser = $this->input->get('namaUser');
        return !$namaUser ? "" : $namaUser;
    } 

    function getTanggalAkhir()
    {
        $tanggalAkhir = $this->input->get('tanggalAkhir');
        return !$tanggalAkhir ? date("d-m-Y") : $tanggalAkhir;
    } 

    function getTanggalStok()
    {
        $tanggalStok = $this->input->get('tanggalStok');
        return !$tanggalStok ? '': $tanggalStok;
    }        

    function getStatus()
    {
        $status = $this->input->get('status');
        return !$status ? 4 : $status;
    }    

    function getCaraBayar()
    {
        $caraBayar = $this->input->get('caraBayar');
        return !$caraBayar ? 4 : $caraBayar;
    } 

    function getInfoSistem()
    {
        return $this->db->get("tInfoSistem")->row();   
    }  
}
