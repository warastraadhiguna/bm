<?php
class UserController extends MY_Controller {
	public function __construct(){
		parent::__construct();
	}
}
?>