<?php
class MY_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->vars([
            'namaSistem' => $this->session->userdata['nama'],
            'divisi' => $this->session->userdata['divisi'],
            'lembaga' => $this->session->userdata['lembaga'],  
            'webUtama' => $this->session->userdata['webUtama'],                                     
        ]);
    }
}
?>