<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Stok_model extends MY_Model
{   
    protected $table = 'tStok';

    function __construct()
    {
        parent::__construct();
    }

    function json() {
        $tanggalStok = $this->input->post('tanggalStok');

        $this->datatables->select("idStok, '' as ID,DATE_FORMAT(tanggalStok, '%d-%m-%Y') as tanggalStok,noBarang,namaBarang,stok, namasatuan,FORMAT(hargaJual, 2, 'de_DE') as hargaJual,FORMAT(hargaBeli, 2, 'de_DE') as hargaBeli, namaUser,case when tglExpired= '0000-00-00 00:00:00' then '' else DATE_FORMAT(tglExpired, '%d-%m-%Y')   end as tglExpired, note");
        if($tanggalStok)
        {
            $tanggalStok = $this->getReverseDate($tanggalStok);
            $this->datatables->where("tanggalStok <='". $tanggalStok ." 23:59:59'");
            $this->datatables->where("tanggalStok >='". $tanggalStok ." 00:00:00'");             
        }
        $this->datatables->from($this->table);    

        return $this->datatables->generate();
    }    
}