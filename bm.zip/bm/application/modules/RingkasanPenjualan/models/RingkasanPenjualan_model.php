<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class RingkasanPenjualan_model extends MY_Model
{   
    protected $order = 'DESC';
    protected $table = 'tNota';

    function __construct()
    {
        parent::__construct();
    }

    function getTotalPenjualanHariIni($tanggalAwal,$tanggalAkhir,$namaUser)
    {
        $tanggalAwal = $this->getReverseDate($tanggalAwal);
        $tanggalAkhir = $this->getReverseDate($tanggalAkhir);

        $query =" SELECT ifNull((sum(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100))),0) as grandTotal   FROM tNota where isPenjualan = 1 and tanggalNota <='". $tanggalAkhir ." 23:59:59' and tanggalNota >='". $tanggalAwal ." 00:00:00' and  namaUser like '%$namaUser%'";
        return  $this->db->query($query)->row()->grandTotal;
    }

    function getTotalPembelianHariIni($tanggalAwal,$tanggalAkhir,$namaUser)
    {
        $tanggalAwal = $this->getReverseDate($tanggalAwal);
        $tanggalAkhir = $this->getReverseDate($tanggalAkhir);

        $query ="select ifNull(sum(a.qty * a.hargaBeli),0) as total  from tTransaksi a, tNota b where a.noNota = b.noNota and b.isPenjualan = 1  and tanggalNota <='". $tanggalAkhir ." 23:59:59'  and tanggalNota >='". $tanggalAwal ." 00:00:00' and  namaUser like '%$namaUser%'";       
        return $this->db->query($query)->row()->total; 
    }
	
    function getTotalNotaHariIni($tanggalAwal,$tanggalAkhir,$namaUser)
    {
        $tanggalAwal = $this->getReverseDate($tanggalAwal);
        $tanggalAkhir = $this->getReverseDate($tanggalAkhir);

        $query =" SELECT ifNull(count(noNota),0) as totalNota   FROM tNota where isPenjualan = 1 and tanggalNota <='". $tanggalAkhir ." 23:59:59' and tanggalNota >='". $tanggalAwal ." 00:00:00' and  namaUser like '%$namaUser%'";
        return  $this->db->query($query)->row()->totalNota;
    }	
}