<section class="content-header">
      <h1>
        <?php echo $namaSistem;?> 
        <small><?php echo $divisi;?> <?php echo $lembaga;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="ringkasanPenjualan"><i class="fa fa-ringkasanPenjualan"></i> Home</a></li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">        
        <div class="box-body">

      <!-- Data RingkasanPenjualan -->
      <div class="row" style="margin-bottom: 10px">
        <div class="col-md-12">
          <h2 style="margin-top:0px">Ringkasan Penjualan Penjualan</h2>
        </div>
      </div>

	<div class="row" style="margin-bottom: 10px">
		<div class="col-md-4">
			<label for="varchar">Range Tanggal</label>
			<div class="form-group row">
				<div class="col-md-4">				
					<input type="text" name="tanggalAwal" value="<?php echo $tanggalAwal;?>" class="form-control waktu" placeholder="Tanggal Awal" id="tanggalAwal">
				</div>
				<div class="col-md-4">				
					<input type="text" name="tanggalAkhir" value="<?php echo $tanggalAkhir;?>" class="form-control waktu" placeholder="Tanggal Akhir" id="tanggalAkhir">
				</div>
			</div>	
		</div>		  
			<div class="col-md-4">
					<label for="varchar">Kasir</label>
					<div class="form-group row">
						<div class="col-md-6">				
						<?php 
							echo getDropdownKasirList($namaUser);
						?>  
						</div>
					</div>
				</div>			
      </div>




      <div class="row" style="margin-bottom: 10px">
         <div class="col-md-4 text-center">
        </div>       
        <div class="col-md-4 text-center">
          <?= showFlashMessage() ?>
        </div>
      </div>
      <table class="table table-bordered table-striped" id="mytable">
        <thead>
          <tr>
            <th width="80px">No</th>
            <th>Jenis Info</th>    
            <th>Nilai</th>        
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Total Penjualan</td>            
            <td class="text-right"><?php echo number_format($totalPenjualanHariIni,0,",",".") ;?></td>                 
          </tr>
          <tr>
            <td>2</td>
            <td>Total Modal</td>            
            <td class="text-right"><?php echo number_format($totalPembelianHariIni,0,",",".") ;?></td>                 
          </tr>          
          <tr>
            <td>3</td>
            <td>Total Laba</td>            
            <td class="text-right"><?php echo number_format($totalPenjualanHariIni - $totalPembelianHariIni,0,",",".") ;?></td>                 
          </tr>   
          <tr>
            <td>4</td>
            <td>Margin Laba</td>            
            <td class="text-right">
			<?php 
				if($totalPenjualanHariIni == 0) echo 0;
				else echo number_format(100*(($totalPenjualanHariIni - $totalPembelianHariIni)/$totalPenjualanHariIni),3,",",".") . "%";
				
			?></td>                 
          </tr>   
          <tr>
            <td>5</td>
            <td>Total Nota</td>            
            <td class="text-right"><?php echo number_format($totalNotaHariIni,0,",",".") ;?></td>                 
          </tr>  		  
        </tbody>
      
      </table>
              </div>
      </div>
    </section>
      <!-- Memanggil jQuery -->
      <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
      <!-- Memanggil jQuery data tables -->
      <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
      <!-- Memanggil Bootstrap data tables -->
      <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
          
      <!-- JavaScript yang berfungsi untuk menampilkan data dari tabel tahun akademik dengan AJAX -->
   <script type="text/javascript">
      $('input[name="tanggalAwal"]').on('change', function() {
        var tanggalAwal = $('input[name="tanggalAwal"]').val();
        var tanggalAkhir = $('input[name="tanggalAkhir"]').val();       
			var namaUser = $('select[name="namaUser"]').val();
			window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&namaUser=' + namaUser, '_self');
      }); 

      $('input[name="tanggalAkhir"]').on('change', function() {
        var tanggalAwal = $('input[name="tanggalAwal"]').val();
        var tanggalAkhir = $('input[name="tanggalAkhir"]').val(); 
			var namaUser = $('select[name="namaUser"]').val();
			window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&namaUser=' + namaUser, '_self');
      }); 
	  
		$('select[name="namaUser"]').on('change', function() {
			var tanggalAwal = $('input[name="tanggalAwal"]').val();
			var tanggalAkhir = $('input[name="tanggalAkhir"]').val();	
			var namaUser = $('select[name="namaUser"]').val();
			window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&namaUser=' + namaUser, '_self');
 		});		  
   </script>