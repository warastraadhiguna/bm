<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class RingkasanPenjualan extends AdminController
{
	function __construct()
    {
        parent::__construct();
		if (!isset($this->session->userdata['ID'])) {
			redirect(base_url("login"));
		}        

		$this->load->model('ringkasanPenjualan/RingkasanPenjualan_model');        		
    }

    public function index()
    {
		$data = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $this->session->userdata['username'],
			'level'    => $this->session->userdata['level'],
		);
		
		$namaUser = $this->RingkasanPenjualan_model->getNamaUser();
		
		$tanggalAwal = $this->RingkasanPenjualan_model->getTanggalAwal();
		$tanggalAkhir = $this->RingkasanPenjualan_model->getTanggalAkhir();
		
		$dataRingkasanPenjualan = array(	
			'tanggalAwal' => $tanggalAwal,	
			'tanggalAkhir' => $tanggalAkhir,	
			'namaUser' => $namaUser,
			'totalPenjualanHariIni'	=> $this->RingkasanPenjualan_model->getTotalPenjualanHariIni($tanggalAwal,$tanggalAkhir,$namaUser),	
			'totalPembelianHariIni'	=> $this->RingkasanPenjualan_model->getTotalPembelianHariIni($tanggalAwal,$tanggalAkhir,$namaUser),	
			'totalNotaHariIni'	=> $this->RingkasanPenjualan_model->getTotalNotaHariIni($tanggalAwal,$tanggalAkhir,$namaUser),	
					
		);

		$this->load->view('header_list',$data); 
		$this->load->view('list', $dataRingkasanPenjualan );  		
		$this->load->view('footer_list');     
    }
}
?>