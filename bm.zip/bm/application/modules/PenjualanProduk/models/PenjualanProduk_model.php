<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class PenjualanProduk_model extends MY_Model
{   
    protected $order = 'DESC';
    protected $table = 'tNota';

    function __construct()
    {
        parent::__construct();
    }

    function json() {
        $tanggalAwal = $this->getReverseDate($this->input->post('tanggalAwal'));
        $tanggalAkhir = $this->getReverseDate($this->input->post('tanggalAkhir'));

        $this->datatables->select("noBarang ,'' as ID, namaBarang, FORMAT(sum(qty), 2, 'de_DE')  as qty  ,  FORMAT(harga, 2, 'de_DE')  as harga,  FORMAT(sum(qty * harga), 2, 'de_DE')  as total"); 
        $this->datatables->from($this->table);                      
        $this->datatables->join("tTransaksi", "tTransaksi.noNota=tNota.noNota");        
        $this->datatables->where("tNota.isPenjualan = 1");  
        $this->datatables->where("tNota.isSelesai = 1");
        $this->datatables->where("tNota.tanggalNota <='". $tanggalAkhir ." 23:59:59'");
        $this->datatables->where("tNota.tanggalNota >='". $tanggalAwal ." 00:00:00'");  
        $this->datatables->group_by("noBarang ,namaBarang");                          

        return $this->datatables->generate();
    } 
}