<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Login extends CI_Controller 
{
	
  function __construct() 
  {
    parent::__construct();
    if ($this->session->userdata('username') AND $this->session->userdata('password') AND $this->session->userdata('level')=='admin') 
    {
      redirect(base_url('admin'));
    }

    $this->load->model(array('Login_model'));
  }
  
  function index() 
  {	  
      $dataSistem = $this->Login_model->getInfoSistem();
      $data = array(  
       'nama'    => $dataSistem->nama . ' ' . $dataSistem->divisi . ' ' . $dataSistem->lembaga,
      );    

      $this->load->view('login',$data); 
  }
  
  function proses() 
  {
    $this->form_validation->set_rules('username', 'username', 'required|trim|xss_clean');
    $this->form_validation->set_rules('password', 'password', 'required|trim|xss_clean');
	
    if ($this->form_validation->run() == FALSE) 
    {		
      $this->index();
    } 
	  else 
    {
      $username = $this->input->post('username');
      $password = $this->input->post('password');
      $user   = $username;  
      $pass   = md5($password);
      $cek    = $this->Login_model->cek($user, $pass);
	    
      if ($cek->num_rows() > 0) 
      {

        $dataInfo = $this->Login_model->getInfoSistem();
        foreach ($cek->result() as $qad) 
        {   
          $sess_data['username'] = $qad->username;
		      $sess_data['ID']    = $qad->ID;
		      $sess_data['level']    = $qad->level;
          $sess_data['idProdi']    = $qad->idProdi;
          $sess_data['nama']    = $dataInfo->nama;
          $sess_data['divisi']    = $dataInfo->divisi;
          $sess_data['lembaga']    = $dataInfo->lembaga;
          $sess_data['webUtama']    = $dataInfo->webUtama;
          $this->session->set_userdata($sess_data);
        }
		
      //  if($sess_data['level'] == 'admin' || $sess_data['level'] == 'superadmin')
      //  {
			  //   $this->session->set_flashdata('success', 'Login Berhasil !');
			 //    redirect(base_url('admin'));
		   // }
      //  else
      //  {
            $this->session->set_flashdata('success', 'Login Berhasil !');
            redirect(base_url('dashboard'));        
       // }
      } 
	    else 
      {
        $this->session->set_flashdata('result_login', '<br>Username atau Password yang anda masukkan salah.');
        redirect(base_url('login'));
      }
    }
  }

  function logout()
  {
    $this->session->sess_destroy();
    redirect(base_url('login'));
  }
}
?>