<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class InfoSistem extends SuperAdminController
{
    private $uploadingDirectory = "./file/tahunpelaksanaan/";     
    private $subDirectory;

	function __construct()
    {
        parent::__construct();
        $this->load->model('infosistem_model'); 
        $this->load->library('form_validation');  
		$this->load->library('datatables');  

		$this->subDirectory = $this->infosistem_model->getDefaultTahunPelaksanaan()->tahun . '/panduan/';			
    }
	
    public function index()
    {		
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$data = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $this->session->userdata['username'],
			'level'    => $this->session->userdata['level'],
		);		

		$row = $this->infosistem_model->get_by_id(1);        
		$dataTambahan = array(
			'button' => 'Update',
			'back'   => site_url('infoSistem'),
			'action' => site_url('infoSistem/update_text_action'),
			'nama' => set_value('nama', $row->nama),
			'divisi' => set_value('divisi', $row->divisi),
			'lembaga' => set_value('lembaga', $row->lembaga),
			'webUtama' => set_value('webUtama', $row->webUtama),						
		);		
		
		$this->load->view('header_list',$data); 
        $this->load->view('infoSistem/infoSistem_list',$dataTambahan);  
		$this->load->view('footer_list');  
    }
	
    public function update_text_action()
    {
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

        $data = array(
			'nama' => $this->input->post('nama',TRUE),
			'divisi' => $this->input->post('divisi',TRUE),
			'lembaga' => $this->input->post('lembaga',TRUE),
			'webUtama' => $this->input->post('webUtama',TRUE),									
		);

        if($this->infosistem_model->update(1,$data))
        {
		 	flashMessage('success', 'Update Record Success.'); 
        }
        else
        	flashMessage('error', 'Update Record gagal!!!'); 

        redirect(site_url('infosistem'));
    }  
}
?>