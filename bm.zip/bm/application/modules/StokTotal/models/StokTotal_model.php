<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class StokTotal_model extends MY_Model
{   
    protected $order = 'DESC';
    protected $table = 'tStok';

    function __construct()
    {
        parent::__construct();
    }

    function json() {
        $this->datatables->select("noBarang, '' as ID,namaBarang,   sum(stok) AS stok, namaSatuan, FORMAT(hargaBeli, 2, 'de_DE')  as hargaBeli,
case when sum(stok) < 0 then 0 else FORMAT(sum(stok*hargaBeli), 2, 'de_DE')   end as nilai"); 
        $this->datatables->from($this->table);                      
        $this->datatables->group_by("noBarang, namaBarang, namaSatuan");                          

        return $this->datatables->generate();
    } 
}