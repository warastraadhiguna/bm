<section class="content-header">
      <h1>
        <?php echo $namaSistem;?> 
        <small><?php echo $divisi;?> <?php echo $lembaga;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo $back ?>">Pembelian</a></li>
		<li class="active">Retur</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">        
        <div class="box-body">

			<!-- Data Pembelian -->
			<div class="row" style="margin-bottom: 10px">
				<div class="col-md-4">
					<h2 style="margin-top:0px">Info Pembelian</h2>
				</div>
				<div class="col-md-4 text-center">
					<?= showFlashMessage() ?>
				</div>
			</div>

		      <table class="table table-bordered table-striped">
		        <tbody>
		          <tr>
		            <td>No Nota</td>            
		            <td><?php echo $row->noNota;?></td>                
		            <td>Cara Bayar</td>            
		            <td><?php echo $row->caraBayar;?></td>    		             
		          </tr>
		          <tr>
		            <td>Tanggal </td>            
		            <td><?php echo $row->tanggalNota;?></td>     
		            <td>Kasir</td>            
		            <td><?php echo $row->namaUser;?></td>    		                         
		          </tr>
		          <tr>
		            <td>Total</td>            
		            <td><?php echo $row->totalSebelumDiskon;?></td>         
		            <td>Member</td>            
		            <td><?php echo $row->namaShopHolder;?></td>    		                   
		          </tr>
		          <tr>
		            <td>Diskon</td>            
		            <td><?php echo $row->diskon;?></td>    
		            <td>Keterangan</td>            
		            <td><?php echo $row->keterangan;?></td>    		                         
		          </tr>          
		          <tr>
		            <td>Potongan</td>            
		            <td><?php echo $row->potongan;?></td>     
		            <td>Bayar</td>            
		            <td><?php echo $row->bayar;?></td>    		                       
		          </tr>      
		          <tr>
		            <td>Grand Total</td>            
		            <td><?php echo $row->grandTotal;?></td>    
		            <td>Kembali</td>            
		            <td><?php echo $row->kembalian;?></td>    		                        
		          </tr>  		
		          <tr>
		            <td>Sisa Hutang</td>            
		            <td><?php echo number_format($row->grandTotalAsli - $totalBayar,0,",",".") . ',00';?></td>    
		            <td></td>            
		            <td></td>    		                        
		          </tr> 		                           
		        </tbody>	      
		      </table>

		     <br/>
		      <hr/>
			<div class="row" style="margin-bottom: 10px">
				<div class="col-md-4">
					<h2 style="margin-top:0px">Detail Retur</h2>
				</div>
				<div class="col-md-4 text-center">
					<?= showFlashMessage() ?>
				</div>
			</div>

			<table class="table table-bordered table-striped" id="mytable">
				<thead>
					<tr>
						<th width="20px">No</th>
						<th>Kode Barang</th>		
						<th>Nama Barang</th>		    
						<th>Qty</th>		
						<th>Satuan</th>									
						<th>Tanggal</th>		 
						<th>Alasan</th>
						<th>Kasir</th>							
					</tr>
				</thead>	
				<tbody>
					<?php 
						$no = 1;
						foreach($details as $data) 
							{
					?>
						<tr>
							<td><?php echo $no; ?></td>
							<td><?php echo $data->noBarang; ?></td>
							<td><?php echo $data->namaBarang; ?></td>
							<td><?php echo $data->qty; ?></td>
							<td><?php echo $data->namaSatuan; ?></td>							
							<td><?php echo str_replace(" 00:00:00","",$data->tanggalRetur); ?></td>
							<td><?php echo $data->alasan; ?></td>		
							<td><?php echo $data->namaUser; ?></td>								
						</tr>
					<?php
						$no++;
						}?>
				</tbody>		
			</table>

		
		
   