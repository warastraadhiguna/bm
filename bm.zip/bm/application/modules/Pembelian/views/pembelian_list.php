<section class="content-header">
      <h1>
        <?php echo $namaSistem;?> 
        <small><?php echo $divisi;?> <?php echo $lembaga;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pembelian</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">        
        <div class="box-body">

			<!-- Data Pembelian -->
			<div class="row" style="margin-bottom: 10px">
				<div class="col-md-4">
					<h2 style="margin-top:0px">Pembelian</h2>
				</div>
				<div class="col-md-4 text-center">
					<?= showFlashMessage() ?>
				</div>
			</div>

			<div class="row" style="margin-bottom: 10px">
				<div class="col-md-4">
					<label for="varchar">Range Tanggal</label>
					<div class="form-group row">
						<div class="col-md-4">				
							<input type="text" name="tanggalAwal" value="<?php echo $tanggalAwal;?>" class="form-control waktu" placeholder="Tanggal Awal" id="tanggalAwal">
						</div>
						<div class="col-md-4">				
							<input type="text" name="tanggalAkhir" value="<?php echo $tanggalAkhir;?>" class="form-control waktu" placeholder="Tanggal Akhir" id="tanggalAkhir">
						</div>
					</div>	
				</div>		
				<div class="col-md-4">
					<label for="varchar">Cara Bayar</label>
					<div class="form-group row">
						<div class="col-md-4">				
							<select name="caraBayar" id ="caraBayar" class="form-control select2" style="width: 100%;">		
								<?php
									if($caraBayar == '4'){
								?>
									<option value="4" selected>Semua</option>
									<option value="1">Cash</option>
									<option value="2">Hutang</option>									
								<?php
									}
									elseif($caraBayar == '1'){
								?>
									<option value="4">Semua</option>
									<option value="1" selected>Cash</option>
									<option value="2">Hutang</option>									
								<?php
									}
									else
									{
										?>
									<option value="4">Semua</option>
									<option value="1">Cash</option>
									<option value="2" selected>Hutang</option>		
									<?php
									}
								?>
							</select>    
						</div>
					</div>
				</div>				
				<div class="col-md-4">
					<label for="varchar">Status</label>
					<div class="form-group row">
						<div class="col-md-4">				
							<select name="status" id ="status" class="form-control select2" style="width: 100%;">		
								<?php
									if($status == '4'){
								?>
									<option value="4" selected>Semua</option>
									<option value="1">Lunas</option>
									<option value="2">Belum</option>									
								<?php
									}
									elseif($status == '1'){
								?>
									<option value="4">Semua</option>
									<option value="1" selected>Lunas</option>
									<option value="2">Belum</option>										
								<?php
									}
									else
									{
										?>
									<option value="4">Semua</option>
									<option value="1">Lunas</option>
									<option value="2" selected>Belum</option>	
										<?php
									}
								?>
							</select>    
						</div>
					</div>
				</div>
			</div>	

			<hr/>
			<table class="table table-bordered table-striped" id="mytable">
				<thead>
					<tr>
						<th width="40px">No</th>
						<th>No Nota</th>	
						<th>Supplier</th>	
						<th>Grand Total</th>							
						<th>Tanggal Nota</th>		    
						<th>Total</th>			
						<th>Diskon</th>		 
						<th>Potongan</th>	  
						<th>Cara Bayar</th>			
						<th>Kasir</th>	
						<th>Status</th>	
						<th width="80px">Action</th>
					</tr>
				</thead>
			
			</table>

			<!-- Memanggil jQuery -->
			<script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
			<!-- Memanggil jQuery data tables -->
			<script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
			<!-- Memanggil Bootstrap data tables -->
			<script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
					
			<!-- JavaScript yang berfungsi untuk menampilkan data dari tabel tahun akademik dengan AJAX -->
			<script type="text/javascript">
				$(document).ready(function() {
					$.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
					{
						return {
							"iStart": oSettings._iDisplayStart,
							"iEnd": oSettings.fnDisplayEnd(),
							"iLength": oSettings._iDisplayLength,
							"iTotal": oSettings.fnRecordsTotal(),
							"iFilteredTotal": oSettings.fnRecordsDisplay(),
							"iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
							"iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
						};
					};

					var t = $("#mytable").dataTable({
						initComplete: function() {
							var api = this.api();
							$('#mytable_filter input')
									.off('.DT')
									.on('keyup.DT', function(e) {
										if (e.keyCode == 13) {
											api.search(this.value).draw();
								}
							});
						},
						oLanguage: {
							sProcessing: "loading..."
						},
						processing: true,
						serverSide: true,
						scrollX: true,
						ajax: {"url": "pembelian/json", 
						"data": function ( data ) {
			                data.tanggalAwal =  $("input[name=tanggalAwal]").val();
			                data.tanggalAkhir =  $("input[name=tanggalAkhir]").val();			     
			                data.caraBayar =  $("select[name=caraBayar]").val();
			                data.status =  $("select[name=status]").val();
			            }, "defaultContent": "",
						"type": "POST"},

						columns: [
							{
								"data": "ID",
								"orderable": false
							},
							{"data": "noNota"},
							{"data": "namaShopHolder"},	
							{"data": "grandTotal","searchable": false, className: "text-right"},
							{"data": "tanggalNota"},
							{
								"data": "totalSebelumDiskon","searchable": false, className: "text-right"
							},												
							{"data": "diskon","searchable": false, className: "text-right"},
							{"data": "potongan","searchable": false, className: "text-right"},
							{
								"data": "caraBayar",
								"render" : function(data){
									var status = "Hutang";
									if(data == 1)
									{
										status = "Cash";	
									}
									return status;
								}
							},	
							{"data": "namaUser"},
							{
								"data": "isSelesai",
								"render" : function(data){
									var status = "Belum";
									if(data == 1)
									{
										status = "Selesai";	
									}
									return status;
								}
							},									
							{
								"data" : "action",
								"orderable": false,
								"className" : "text-center"
							}
						],
						order: [[4, 'asc']],
						rowCallback: function(row, data, iDisplayIndex) {
							var info = this.fnPagingInfo();
							var page = info.iPage;
							var length = info.iLength;
							var index = page * length + (iDisplayIndex + 1);
							$('td:eq(0)', row).html(index);
						}
					});
				});

					$('input[name="tanggalAwal"]').on('change', function() {
						var tanggalAwal = $('input[name="tanggalAwal"]').val();
						var tanggalAkhir = $('input[name="tanggalAkhir"]').val();	
						var status = $('select[name="status"]').val();
						var caraBayar = $('select[name="caraBayar"]').val();	
					  	window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&status=' + status + '&caraBayar=' + caraBayar, '_self');
					});	

					$('input[name="tanggalAkhir"]').on('change', function() {
						var tanggalAwal = $('input[name="tanggalAwal"]').val();
						var tanggalAkhir = $('input[name="tanggalAkhir"]').val();
						var status = $('select[name="status"]').val();
						var caraBayar = $('select[name="caraBayar"]').val();	
					  	window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&status=' + status + '&caraBayar=' + caraBayar, '_self');
					});	

					$('select[name="status"]').on('change', function() {
						var tanggalAwal = $('input[name="tanggalAwal"]').val();
						var tanggalAkhir = $('input[name="tanggalAkhir"]').val();	
						var status = $('select[name="status"]').val();
						var caraBayar = $('select[name="caraBayar"]').val();	
					  	window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&status=' + status + '&caraBayar=' + caraBayar, '_self');
					});	

					$('select[name="caraBayar"]').on('change', function() {
						var tanggalAwal = $('input[name="tanggalAwal"]').val();
						var tanggalAkhir = $('input[name="tanggalAkhir"]').val();
						var status = $('select[name="status"]').val();
						var caraBayar = $('select[name="caraBayar"]').val();	
					  	window.open(window.location.pathname + '?tanggalAwal=' + tanggalAwal + '&tanggalAkhir=' + tanggalAkhir + '&status=' + status + '&caraBayar=' + caraBayar, '_self');
					});						
			</script>

		
   