<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pembelian_model extends MY_Model
{   
    protected $table = 'tNota';

    function __construct()
    {
        parent::__construct();
    }

    function json() {
        $tanggalAwal = $this->getReverseDate($this->input->post('tanggalAwal'));
        $tanggalAkhir = $this->getReverseDate($this->input->post('tanggalAkhir'));
        $status = $this->input->post('status');
        $caraBayar = $this->input->post('caraBayar');

        $this->datatables->select("noNota,'' as ID, DATE_FORMAT(tanggalNota, '%d-%m-%Y %H:%i')  as tanggalNota ,FORMAT(totalSebelumDiskon, 2, 'de_DE')  as totalSebelumDiskon,diskon,potongan,FORMAT(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100), 2, 'de_DE') as grandTotal, caraBayar  ,noReferensi, namaUser, ifnull(namaShopHolder,'') as namaShopHolder,keterangan ,bayar,kembalian,isSelesai"); 
        $this->datatables->where("isPenjualan = 0");  
        if($status != '4') $this->datatables->where("isSelesai =" . $status);
        if($caraBayar != '4') $this->datatables->where("caraBayar =" . $caraBayar);        
        $this->datatables->where("tanggalNota <='". $tanggalAkhir ." 23:59:59'");
        $this->datatables->where("tanggalNota >='". $tanggalAwal ." 00:00:00'");            
        $this->datatables->from($this->table);   		
        $this->datatables->add_column('action', anchor(site_url('pembelian/detail/$1'),'<button type="button" class="btn btn-info" title="Lihat Detail"><i class="fa fa-search" aria-hidden="true"></i></button>').' '.anchor(site_url('pembelian/retur/$1'),'<button type="button" class="btn btn-warning" title="Lihat Retur"><i class="fa fa-refresh" aria-hidden="true"></i></button>').' '.anchor(site_url('pembelian/cicilan/$1'),'<button type="button" class="btn btn-success" title="Lihat Cicilan"><i class="fa fa-money" aria-hidden="true"></i></button>'), 'noNota');
        return $this->datatables->generate();
    } 

    function getNota($id)
    {
        $id = str_replace("%20"," ",$id);
        $query = "select noNota,'' as ID,  DATE_FORMAT(tanggalNota, '%d-%m-%Y %H:%i')  as tanggalNota  ,FORMAT(totalSebelumDiskon, 2, 'de_DE')  as totalSebelumDiskon,diskon,potongan,FORMAT(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100), 2, 'de_DE') as grandTotal, totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100) as grandTotalAsli, case when caraBayar = 1 then 'Tunai' else 'Hutang' end as caraBayar,noReferensi, namaUser, ifnull(namaShopHolder,'') as namaShopHolder,keterangan ,FORMAT(bayar, 2, 'de_DE') as bayar,FORMAT(kembalian, 2, 'de_DE') as kembalian from tNota where noNota='$id'";
        return $this->db->query($query)->row();
    }

    function getDetailNota($id)
    {
        $id = str_replace("%20"," ",$id);        
        $query = "SELECT noBarang  ,namaBarang,qty, namaSatuan,harga, ifnull(diskon,0) as diskon, ifnull(diskon2,0) as diskon2, ifnull(potongan,0) as potongan, ifnull(ppn,0) as ppn, '0' as hargaSetelahPPn, '0' as subTotal, ifnull(tglExpired,'') as tglExpired, idStok FROM tTransaksi where noNota ='$id'";


        $data = $this->db->query($query)->result();

        foreach ($data as $singleData) 
        {
            $hargatemp = $singleData->harga;
            $qty = $singleData->qty;

            $hargaSementara = $hargatemp;
            if ($singleData->diskon != 0)
            {
                if ($singleData->diskon2 <= 0)
                {
                    $hargaSementara = $hargatemp - ($hargatemp * $singleData->diskon / 100);
                }
                else
                {
                    $nilai = $hargatemp - ($hargatemp * $singleData->diskon / 100);
                    $hargaSementara = $nilai - ($nilai * $singleData->diskon2 / 100);
                }
            }

            $hargaSetelahDiskon = $hargaSementara - $singleData->potongan;
                        
            $hargaSetelahPpn = $hargaSetelahDiskon + ($hargaSetelahDiskon * $singleData->ppn/100);
            $singleData->hargaSetelahPpn = $hargaSetelahPpn;
            $singleData->subTotal = $hargaSetelahPpn * $qty;
        }

        return $data;
    }    

    function getRetur($id)
    {
        $id = str_replace("%20"," ",$id);    
        $query = "SELECT noBarang,namaBarang, qty, namaSatuan, tanggalRetur, alasan, namaUser FROM tretur a inner join trincianRetur b on a.noRetur=b.noRetur where noNota ='$id'";
        return $this->db->query($query)->result();
    }       

    function getCicilan($id)
    {
        $id = str_replace("%20"," ",$id);    
        $query = "SELECT DATE_FORMAT(tanggal, '%d-%m-%Y')  as tanggal,FORMAT(nilai, 2, 'de_DE')  as nilai FROM tcicilanhutang  where noNota ='$id' and nilai>0";
        return $this->db->query($query)->result();
    }   

    function getTotalBayar($id)
    {
        $id = str_replace("%20"," ",$id);    
        $query = "SELECT  ifNull(sum(nilai),0) as total FROM tcicilanhutang  where noNota ='$id' and nilai>0";
        return $this->db->query($query)->row()->total;
    }
}