<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class Pembelian extends UserController
{
	function __construct()
    {
        parent::__construct();
        $this->load->model('Pembelian_model'); 
        $this->load->model('Users/Users_model');         
        $this->load->library('form_validation');       
		$this->load->library('datatables'); 
    }
	
    public function index()
    {
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  		

		$dataTambahan = array(
			'tanggalAwal' => $this->Pembelian_model->getTanggalAwal(),	
			'tanggalAkhir' => $this->Pembelian_model->getTanggalAkhir(),		
			'status'	  =>  $this->Pembelian_model->getStatus(),	
			'caraBayar'		=>  $this->Pembelian_model->getCaraBayar() ,
		);	

		$this->load->view('header_list',$dataAdm); 
        $this->load->view('pembelian/pembelian_list', $dataTambahan); 
		$this->load->view('footer_list'); 
    } 
    
    public function json() 
    {
        header('Content-Type: application/json');
        echo $this->Pembelian_model->json();
    }
   
    public function detail($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Pembelian_model->getNota($id);
        if ($row) 
        {
            $data = array(
				'back'   => site_url('pembelian'),
				'row'	 => $row,
				'details'=> $this->Pembelian_model->getDetailNota($id),
				'totalBayar' => $this->Pembelian_model->getTotalBayar($id)
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('pembelian/pembelian_detail', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('pembelian'));
        }
    }

    public function retur($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Pembelian_model->getNota($id);

        if ($row) 
        {
            $data = array(
				'back'   => site_url('pembelian'),
				'row'	 => $row,
				'details'=> $this->Pembelian_model->getRetur($id),
				'totalBayar' => $this->Pembelian_model->getTotalBayar($id)				
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('pembelian/pembelian_retur', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('pembelian'));
        }
    }

    public function cicilan($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Pembelian_model->getNota($id);

        if ($row) 
        {
            $data = array(
				'back'   => site_url('pembelian'),
				'row'	 => $row,
				'details'=> $this->Pembelian_model->getCicilan($id),
				'totalBayar' => $this->Pembelian_model->getTotalBayar($id)				
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('pembelian/pembelian_cicilan', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('pembelian'));
        }
    }

}
?>