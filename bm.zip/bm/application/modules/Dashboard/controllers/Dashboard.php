<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends UserController
{
	function __construct()
    {
        parent::__construct();
		if (!isset($this->session->userdata['ID'])) {
			redirect(base_url("login"));
		}        

		$this->load->model('dashboard/Dashboard_model');        		
    }

    public function index()
    {
		$levelUser = $this->session->userdata['level'];
		$data = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $this->session->userdata['username'],
			'level'    => $levelUser,
		);
		date_default_timezone_set('Asia/Jakarta');
		$dataDashboard = array(	
			'tahun'       				=> date("d/m/Y H:i"),
			'totalPenjualanHariIni'		=> $this->Dashboard_model->getTotalPenjualanHariIni(),	
			'totalPembelianHariIni'		=> $this->Dashboard_model->getTotalPembelianHariIni(),	
			'totalNotaHariIni'			=> $this->Dashboard_model->getCountNotaHariIni(),
			'totalStokHariIni'			=> $this->Dashboard_model->getTotalStokHariIni(),
			'totalHutangHariIni'		=> $this->Dashboard_model->getTotalHutangHariIni(),
		);

		$this->load->view('header_list',$data); 
		if($levelUser === "admin")
		{
			$this->load->view('dashboard', $dataDashboard );  		
		}
		else
		{
			$this->load->view('welcome');  		
		}
		
		$this->load->view('footer_list');     
    }
}
?>