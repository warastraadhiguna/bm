<section class="content-header">
      <h1>
        <?php echo $namaSistem;?> 
        <small><?php echo $divisi;?> <?php echo $lembaga;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">        
        <div class="box-body">

      <!-- Data Dashboard -->
      <div class="row" style="margin-bottom: 10px">
        <div class="col-md-12">
          <h2 style="margin-top:0px">Dashboard Penjualan Tanggal <?php echo $tahun;?></h2>
        </div>
      </div>
      <div class="row" style="margin-bottom: 10px">
         <div class="col-md-4 text-center">
        </div>       
        <div class="col-md-4 text-center">
          <?= showFlashMessage() ?>
        </div>
      </div>
      <table class="table table-bordered table-striped"  width="50%"  id="mytable">
        <thead>
          <tr>
            <th width="80px">No</th>
            <th>Jenis Info</th>    
            <th>Nilai</th>        
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Total Penjualan Hari Ini</td>            
            <td class="text-right"><?php echo number_format($totalPenjualanHariIni,0,",",".") ;?></td>                 
          </tr>
          <tr>
            <td>2</td>
            <td>Total Modal Hari Ini</td>            
            <td class="text-right"><?php echo number_format($totalPembelianHariIni,0,",",".") ;?></td>                 
          </tr>          
          <tr>
            <td>3</td>
            <td>Total Laba Hari Ini</td>            
            <td class="text-right"><?php echo number_format($totalPenjualanHariIni - $totalPembelianHariIni,0,",",".") ;?></td>                 
          </tr>      
          <tr>
            <td>4</td>
            <td>Margin Laba Hari Ini</td>            
            <td class="text-right">
			<?php 
				if($totalPenjualanHariIni == 0) echo 0;
				else echo number_format(100*(($totalPenjualanHariIni - $totalPembelianHariIni)/$totalPenjualanHariIni),3,",",".") . "%";
				
			?></td>                 
          </tr>  
          <tr>
            <td>5</td>
            <td>Total Nota Hari Ini</td>            
			<td class="text-right"><?php echo number_format($totalNotaHariIni,0,",",".") ;?></td>                 
          </tr>      
          <tr>
            <td>6</td>
            <td>Total Stok Hari Ini</td>            
			<td class="text-right"><?php echo number_format($totalStokHariIni,0,",",".") ;?></td>                 
          </tr>    
           <tr>
            <td>7</td>
            <td>Total Hutang Hari Ini</td>            
			<td class="text-right"><?php echo number_format($totalHutangHariIni,0,",",".") ;?></td>                 
          </tr>   
           <tr>
            <td>8</td>
            <td>Leverage Hari Ini</td>            
			<td class="text-right"><?php echo number_format(($totalHutangHariIni / $totalStokHariIni) * 100,2,",",".") ;?>%</td>                 
          </tr>  		  
        </tbody>
      
      </table>
              </div>
      </div>
    </section>
      <!-- Memanggil jQuery -->
      <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
      <!-- Memanggil jQuery data tables -->
      <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
      <!-- Memanggil Bootstrap data tables -->
      <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
          
      <!-- JavaScript yang berfungsi untuk menampilkan data dari tabel tahun akademik dengan AJAX -->
   