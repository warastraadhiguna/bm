<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard_model extends MY_Model
{   
    protected $order = 'DESC';
    protected $table = 'tNota';
    private $tanggalAwal,$tanggalAkhir;

    function __construct()
    {
        parent::__construct();
        $this->tanggalAwal = date("Y/m/d 00:00:00");
        $this->tanggalAkhir = date("Y/m/d 23:59:59");
    }

    function getTotalPenjualanHariIni()
    {
        $query =" SELECT ifNull((sum(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100))),0) as grandTotal   FROM tNota where isPenjualan = 1 and tanggalNota <='". $this->tanggalAkhir ."' and tanggalNota >='". $this->tanggalAwal ."'";
        return $this->db->query($query)->row()->grandTotal;
    }

    function getTotalPembelianHariIni()
    {
        $query ="select ifNull(sum(a.qty * a.hargaBeli),0) as total  from tTransaksi a, tNota b where a.noNota = b.noNota and b.isPenjualan = 1  and tanggalNota <='". $this->tanggalAkhir ."'  and tanggalNota >='". $this->tanggalAwal ."'";       
        return $this->db->query($query)->row()->total; 
    }
	
	function getCountNotaHariIni()
	{
       $query =" SELECT ifNull(count(noNota),0) as totalNota   FROM tNota where isPenjualan = 1 and tanggalNota <='". $this->tanggalAkhir ."' and tanggalNota >='". $this->tanggalAwal ."'";
        return $this->db->query($query)->row()->totalNota;		
	}
	
	function getTotalStokHariIni()
	{
       $query ="SELECT sum(hargaBeli*stok) as total FROM tstok where stok>0";
        return $this->db->query($query)->row()->total;		
	}	
	
	function getTotalHutangHariIni()
	{
		$query ="select Ceiling(sum(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100))) as totalHutang from tNota   where isSelesai = 2";
		$totalHutangSemua = $this->db->query($query)->row()->totalHutang;

		$query ="select SUM(nilai) as cicilan from tCicilanHutang a inner join tNota b on a.noNota=b.noNota where b.isSelesai=2 and nilai>0";
		$cicilan = $this->db->query($query)->row()->cicilan;
		
		return $totalHutangSemua - $cicilan;
	}	
}