<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class Users extends AdminController
{
	function __construct()
    {
        parent::__construct();
        $this->load->model('Users_model'); 
        $this->load->library('form_validation');       
		$this->load->library('datatables'); 
    }
	
    public function index()
    {
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  		

		$this->load->view('header_list',$dataAdm); 
        $this->load->view('users/users_list'); 
		$this->load->view('footer_list'); 
    } 
    
    public function json() 
    {
        header('Content-Type: application/json');
        echo $this->Users_model->json();
    }

    public function create()
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  		

        $data = array(
            'button' => 'Create',
			'back'   => site_url('users'),
            'action' => site_url('users/create_action'),
	        'username' => set_value('username'),
	        'password' => set_value('password'),
	        'nama' => set_value('nama'),
	        'level' => 'admin',
	        'isActive' => set_value('isActive')             
		);
		
		$this->load->view('header',$dataAdm);
        $this->load->view('users/users_form', $data); 
		$this->load->view('footer'); 
    }
    

    public function create_action()
    {
		if (!isset($this->session->userdata['username'])) 
		{
			redirect(base_url("login"));
		}
	
        $this->_rules(); 

        if ($this->form_validation->run() == FALSE) 
        {
            $this->create();
        } 
		else 
		{
			$level = $this->input->post('level',TRUE);
            $data = array(
				'username' => $this->input->post('username',TRUE),
				'password' => md5($this->input->post('password',TRUE)),
				'nama' => $this->input->post('nama',TRUE),
				'level' => $level,				
				'isActive' => $this->input->post('isActive',TRUE),
				'id_sessions' => md5($this->input->post('password',TRUE))
	    	);
           
            if($this->Users_model->insert($data))
        	    flashMessage('success', 'Create Record Success.');
        	else
         	    flashMessage('error', 'Create Record Gagal.');       		
            redirect(site_url('users'));
        }
    }
    

    public function update($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Users_model->get_by_id($id);

        if ($row) 
        {
            $data = array(
                'button' => 'Update',
				'back'   => site_url('users'),
                'action' => site_url('users/update_action'),
				'username' => set_value('username', $row->username),	
				'nama' => set_value('nama', $row->nama),	
				'ID' => set_value('ID', $row->ID),		
				'level' => set_value('level', $row->level),
				'isActive' => set_value('isActive', $row->isActive)			  
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('users/users_form', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('users'));
        }
    }

    public function update_action()
    {
		if (!isset($this->session->userdata['ID'])) {
			redirect(base_url("login"));
		}

        $this->_rules();
		
        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('ID', TRUE));
        } 	
		else{
			$level = $this->input->post('level',TRUE);

            $data = array(
				'username' => $this->input->post('username',TRUE),
				'nama' => $this->input->post('nama',TRUE),
				'ID' =>   $this->input->post('ID',TRUE) ,					
				'level' => $level,
				'isActive' => $this->input->post('isActive',TRUE),
				'id_sessions' => md5($this->input->post('password',TRUE))			
		    );

            if($this->Users_model->update($this->input->post('ID', TRUE), $data))
		 		flashMessage('success', 'Update Record Success.'); 
		 	else
		 		flashMessage('error', 'Update Record Gagal.'); 
            redirect(site_url('users'));
        }
    }

    public function update_password_action()
    {
		if (!isset($this->session->userdata['ID'])) {
			redirect(base_url("login"));
		}

        $data = array(
			'password' => md5($this->input->post('password',TRUE))
	    );

        if($this->Users_model->update($this->input->post('IdUser', TRUE), $data))
	 		flashMessage('success', 'Update Password Success.'); 
	 	else
	 		flashMessage('error', 'Update Password Gagal.'); 
        redirect(site_url('users'));
 
    }    
 
    public function delete($id)
    {		
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
        $row = $this->Users_model->get_by_id($id);
        if ($row) 
        {
            $this->Users_model->delete($id);
            flashMessage('success', 'Delete Record Success.'); 
            redirect(site_url('users'));
        } 
		else 
		{
            flashMessage('error', 'Record Not Found.'); 			
            redirect(site_url('users'));
        }
    }

    public function _rules() 
    {
		$this->form_validation->set_rules('username', 'username', 'trim|required');	
		$this->form_validation->set_rules('nama', 'nama', 'trim|required');		
		$this->form_validation->set_rules('level', 'level', 'trim|required');
		$this->form_validation->set_rules('isActive', 'isActive', 'trim|required');
		$this->form_validation->set_rules('username', 'username', 'trim');
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}
?>