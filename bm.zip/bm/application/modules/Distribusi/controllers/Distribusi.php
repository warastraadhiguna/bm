<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class Distribusi extends UserController
{
	function __construct()
    {
        parent::__construct();
        $this->load->model('Distribusi_model'); 
        $this->load->model('Users/Users_model');         
        $this->load->library('form_validation');       
		$this->load->library('datatables'); 
    }
	
    public function index()
    {
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  		

		$dataTambahan = array(
			'tanggalAwal' => $this->Distribusi_model->getTanggalAwal(),	
			'tanggalAkhir' => $this->Distribusi_model->getTanggalAkhir() ,			
		);	

		$this->load->view('header_list',$dataAdm); 
        $this->load->view('distribusi/distribusi_list', $dataTambahan); 
		$this->load->view('footer_list'); 
    } 
    
    public function json() 
    {
        header('Content-Type: application/json');
        echo $this->Distribusi_model->json();
    }

    public function tambah()
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $data = array(
			'back'   => site_url('distribusi'),
		);

		$this->load->view('header', $dataAdm); 
        $this->load->view('distribusi/tambah', $data); 
		$this->load->view('footer'); 
    }    

    public function tambah_distribusi()
    {	
		$i = $this->input;
		$data = array(
						'kode_barang' 			=> $i->post('kode_barang'), 	
						'harga' 			=> $i->post('harga'), 
						'jumlah' 			=> $i->post('stok'), 
					 );

		$this->Distribusi_model->add($data);
		$this->session->set_flashdata('sukses', 'Data telah ditambah.');
			$this->session->set_flashdata('sukses', 'Data telah ditambah.');		
		redirect(base_url('distribusi/tambah'),'refresh');
    }         
}
?>