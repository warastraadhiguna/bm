<section class="content-header">
      <h1>
        <?php echo $namaSistem;?> 
        <small><?php echo $divisi;?> <?php echo $lembaga;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Distribusi</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">

<?php 
	if($this->session->flashdata('sukses'))
	{
		echo '<p class="alert alert-success">';
		echo $this->session->flashdata('sukses');
		echo "</p>";
	}


echo validation_errors('<div class="alert alert-warning">','</div>');
echo form_open(base_url('distribusi/tambah_distribusi'), ' class="form-horizontal"');
	?>

<div class="form-group row">
	<label class="col-sm-2 col-form-label">Kode Barang</label>
	<div class="col-sm-3">
		<input type="text" name="kode_barang" required>
	</div>
</div>

<div class="form-group row">
	<label class="col-sm-2 col-form-label">Harga</label>
	<div class="col-sm-3">
		<input type="number" name="harga" required>
	</div>
</div>

<div class="form-group row">
	<label class="col-sm-2 col-form-label">Stok</label>
	<div class="col-sm-3">
		<input type="number" name="stok" required>
	</div>
</div>

<div class="form-group row">
	<label class="col-sm-2 col-form-label"></label>
	<div class="col-sm-5">
		<button class="btn btn-success btn-lg"  name="submit" type="submit">
			<i class="fa fa-save"></i> Simpan
		</button>
		<button class="btn btn-info btn-lg"  name="reset" type="reset">
			<i class="fa fa-times"></i> Batal
		</button>
	</div>
</div>

<?php echo form_close();?>

<script type="text/javascript" charset="utf-8" async defer>
function check_number2()
{  
    var number = document.getElementById("kapasitas").value.replace(/\./g,'');
    var isNumber = !isNaN(parseFloat(number)) && isFinite(number);
    if(!isNumber)
    {
    	alert("Isi dengan angka!!!");
		number = 0;
    }

    document.getElementById("kapasitas").value = number;
}
</script>


<!-- Memanggil jQuery -->
<script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
<!-- Memanggil Bootstrap data tables -->
<script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
					

		
   