<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Distribusi_model extends MY_Model
{   
    protected $table = 'tNota';

    function __construct()
    {
        parent::__construct();
    }

    function json() {
        $tanggalAwal = $this->getReverseDate($this->input->post('tanggalAwal'));
        $tanggalAkhir = $this->getReverseDate($this->input->post('tanggalAkhir'));

        $this->datatables->select("noNota,'' as ID, DATE_FORMAT(tanggalNota, '%d-%m-%Y %H:%i')  as tanggalNota ,FORMAT(totalSebelumDiskon, 2, 'de_DE')  as totalSebelumDiskon,diskon,potongan,FORMAT(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100), 2, 'de_DE') as grandTotal, caraBayar  ,noReferensi, namaUser, ifnull(namaShopHolder,'') as namaShopHolder,keterangan ,bayar,kembalian"); 
        $this->datatables->where("isDistribusi = 1");  
        $this->datatables->where("isSelesai = 1");
        $this->datatables->where("tanggalNota <='". $tanggalAkhir ." 23:59:59'");
        $this->datatables->where("tanggalNota >='". $tanggalAwal ." 00:00:00'");            
        $this->datatables->from($this->table);    
        $this->datatables->add_column('action', anchor(site_url('distribusi/detail/$1'),'<button type="button" class="btn btn-info" title="Lihat Detail"><i class="fa fa-search" aria-hidden="true"></i></button>').' '.anchor(site_url('distribusi/retur/$1'),'<button type="button" class="btn btn-warning" title="Lihat Retur"><i class="fa fa-refresh" aria-hidden="true"></i></button>'), 'noNota');
        return $this->datatables->generate();
    } 

    function getNota($id)
    {
        $query = "select noNota,'' as ID,  DATE_FORMAT(tanggalNota, '%d-%m-%Y %H:%i')  as tanggalNota  ,FORMAT(totalSebelumDiskon, 2, 'de_DE')  as totalSebelumDiskon,diskon,potongan,FORMAT(totalSebelumDiskon-potongan-(totalSebelumDiskon*diskon/100), 2, 'de_DE') as grandTotal, case when caraBayar = 1 then 'Tunai' when caraBayar = 2 then 'Debit' else 'Kredit' end as caraBayar,noReferensi, namaUser, ifnull(namaShopHolder,'') as namaShopHolder,keterangan ,FORMAT(bayar, 2, 'de_DE') as bayar,FORMAT(kembalian, 2, 'de_DE') as kembalian from tNota where noNota='$id'";
        return $this->db->query($query)->row();
    }

    function getDetailNota($id)
    {
        $query = "select noBarang,namaBarang,namaSatuan ,qtyTampil,hargaJualSatuan, (qtyTampil*hargaJualSatuan) as total  FROM tTransaksi where noNota ='$id'";
        return $this->db->query($query)->result();
    }    

     function getRetur($id)
    {
        $query = "SELECT noBarang,namaBarang, qty, namaSatuan, tanggalRetur, alasan, namaUser FROM tretur a inner join trincianRetur b on a.noRetur=b.noRetur where noNota ='$id'";
        return $this->db->query($query)->result();
    }    

        public function add($data)
    {
        return $this->db->insert('tdistribusi', $data);
    }   
}