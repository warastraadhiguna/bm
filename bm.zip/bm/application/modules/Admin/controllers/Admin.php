<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin extends CI_Controller 
{
	function __construct() 
	{
		parent::__construct();
		$this->load->model('Users/Users_model');
		if (!isset($this->session->userdata['ID'])) {
			redirect(base_url("login"));
		}
	}
	
	public function index() 
	{
		$row = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$data = array(	
			'wa'       => 'Web administrator',
			'univ'     => 'LPMAI UKSW',
			'username' => $row->username,
			'level'    => $row->level,
		);
		
		$this->load->view('beranda',$data);  		
	}

	function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}
}
?>