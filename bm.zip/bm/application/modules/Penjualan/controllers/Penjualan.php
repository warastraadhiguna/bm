<?php 

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class Penjualan extends UserController
{
	function __construct()
    {
        parent::__construct();
        $this->load->model('Penjualan_model'); 
        $this->load->model('Users/Users_model');         
        $this->load->library('form_validation');       
		$this->load->library('datatables'); 
    }
	
    public function index()
    {
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}

		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  		

		$dataTambahan = array(
			'tanggalAwal' => $this->Penjualan_model->getTanggalAwal(),	
			'tanggalAkhir' => $this->Penjualan_model->getTanggalAkhir() ,			
		);	

		$this->load->view('header_list',$dataAdm); 
        $this->load->view('penjualan/penjualan_list', $dataTambahan); 
		$this->load->view('footer_list'); 
    } 
    
    public function json() 
    {
        header('Content-Type: application/json');
        echo $this->Penjualan_model->json();
    }
   
    public function detail($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Penjualan_model->getNota($id);

        if ($row) 
        {
            $data = array(
				'back'   => site_url('penjualan'),
				'row'	 => $row,
				'details'=> $this->Penjualan_model->getDetailNota($id)
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('penjualan/penjualan_detail', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('penjualan'));
        }
    }

    public function retur($id)
    {	
		if (!isset($this->session->userdata['username'])) {
			redirect(base_url("login"));
		}
	
		$rowAdm = $this->Users_model->get_by_id($this->session->userdata['ID']);
		$dataAdm = array(	
			'wa'       => $this->session->userdata['nama'],
			'univ'     => $this->session->userdata['divisi'] . ' ' . $this->session->userdata['lembaga'],
			'username' => $rowAdm->username,
			'level'    => $rowAdm->level,
		);  

        $row = $this->Penjualan_model->getNota($id);

        if ($row) 
        {
            $data = array(
				'back'   => site_url('penjualan'),
				'row'	 => $row,
				'details'=> $this->Penjualan_model->getRetur($id)
			);

			$this->load->view('header', $dataAdm); 
            $this->load->view('penjualan/penjualan_retur', $data); 
			$this->load->view('footer'); 
        } 
		else
		 {
		 	flashMessage('error', 'Record Not Found.');
            redirect(site_url('penjualan'));
        }
    }
}
?>